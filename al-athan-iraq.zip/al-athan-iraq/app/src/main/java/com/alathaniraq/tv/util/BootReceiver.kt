package com.alathaniraq.tv.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.alathaniraq.tv.ui.SplashActivity

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // MainActivity (reached via the splash screen) re-fetches timings on launch
            // and re-schedules today's alarms. For a production app, replace this with a
            // WorkManager periodic job that re-fetches and reschedules once per day
            // without requiring the UI to open.
            val launch = Intent(context, SplashActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("silent_boot_refresh", true)
            }
            context.startActivity(launch)
        }
    }
}
