package com.alathaniraq.tv.ui

import android.app.Activity
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import com.alathaniraq.tv.databinding.ActivityColorSchemePickerBinding
import com.alathaniraq.tv.util.Prefs

/**
 * Shows each preset as a button rendered in its own colors, so the person can see
 * exactly what they're picking before committing. Selecting one saves it immediately
 * and returns — both home screen designs read it via ColorSchemes.current() on their
 * next refresh() (MenuActivity's result-propagation triggers that automatically).
 */
class ColorSchemePickerActivity : BaseActivity() {

    private lateinit var binding: ActivityColorSchemePickerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityColorSchemePickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val currentId = Prefs.getColorSchemeId(this)
        var selectedButton: Button? = null

        ColorSchemes.all(this).forEach { scheme ->
            val button = Button(this).apply {
                text = getString(scheme.labelRes)
                setTextColor(scheme.primaryText)
                isFocusable = true
                isAllCaps = false
                textSize = 17f
                setPadding(48, 48, 48, 48)

                val density = resources.displayMetrics.density
                val corners = 8f * density
                val borderWidth = (if (scheme.id == currentId) 4 else 2) * density
                val borderColor = if (scheme.id == currentId) scheme.accentText else scheme.primaryText
                background = GradientDrawable().apply {
                    setColor(scheme.background)
                    cornerRadius = corners
                    setStroke(borderWidth.toInt(), borderColor)
                }

                setOnClickListener {
                    Prefs.setColorSchemeId(this@ColorSchemePickerActivity, scheme.id)
                    setResult(Activity.RESULT_OK)
                    finish()
                }
            }

            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = (16 * resources.displayMetrics.density).toInt()
            }
            binding.schemeList.addView(button, params)

            if (scheme.id == currentId) selectedButton = button
        }

        (selectedButton ?: binding.schemeList.getChildAt(0) as? Button)?.requestFocus()
    }
}
