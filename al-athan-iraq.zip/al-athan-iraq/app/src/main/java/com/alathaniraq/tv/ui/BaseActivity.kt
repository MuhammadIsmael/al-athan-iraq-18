package com.alathaniraq.tv.ui

import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.alathaniraq.tv.util.DeviceUtils
import com.alathaniraq.tv.util.LocaleHelper
import com.alathaniraq.tv.util.Prefs

/**
 * Applies two app-wide, cross-cutting user preferences to every screen automatically:
 * - Language (English/Arabic/Kurdish Sorani, chosen during first-launch setup or
 *   changeable later)
 * - Screen orientation — but only actually *locked* on Android TV. TVs have no
 *   rotation sensor, so a hard lock is the only way to support a TV that's physically
 *   mounted in portrait (e.g. a narrow mosque display). On phones and tablets, forcing
 *   a fixed orientation fights the device's real rotation and the person's system
 *   rotation-lock setting — so there, the orientation preference from setup is not
 *   enforced as a lock; the screen simply follows whatever the device/OS decides,
 *   which is what people expect from a normal phone app.
 *
 * Individual activities don't need to do anything extra — just extend this instead
 * of ComponentActivity.
 */
abstract class BaseActivity : ComponentActivity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyPreferredOrientation()
    }

    private fun applyPreferredOrientation() {
        requestedOrientation = if (DeviceUtils.isTvDevice(this)) {
            if (Prefs.getPreferredOrientation(this) == Prefs.ORIENTATION_PORTRAIT) {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            } else {
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }
        } else {
            // Follow the device's own rotation and the system's rotation-lock setting
            // (SCREEN_ORIENTATION_USER honors a manual system rotation lock the same
            // way the home screen and other apps do; when unlocked it follows the
            // sensor, landscape when the phone is landscape and portrait when it's
            // portrait, as expected).
            ActivityInfo.SCREEN_ORIENTATION_USER
        }
    }
}
