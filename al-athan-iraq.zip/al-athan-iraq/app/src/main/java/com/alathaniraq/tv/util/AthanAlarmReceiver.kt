package com.alathaniraq.tv.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import com.alathaniraq.tv.R

class AthanAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // NOTE: res/raw/athan.mp3 is not bundled in this source tree — add your own
        // licensed athan audio file there before building. See README.
        try {
            val player = MediaPlayer()
            val afd = context.resources.openRawResourceFd(R.raw.athan)
            player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setOnCompletionListener { it.release() }
            player.prepare()
            player.start()
        } catch (e: Exception) {
            // No athan.mp3 present, or playback failed — fail silently rather than crash.
        }
    }

    companion object {
        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
    }
}
